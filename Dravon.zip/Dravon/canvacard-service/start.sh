#!/bin/bash
cd /workspaces/Learning/Dravon/canvacard-service
npm install
npm start