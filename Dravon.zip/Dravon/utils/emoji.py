class EmojiHandler:
    def __init__(self):
        pass
    
    def replace_emojis(self, content):
        return content